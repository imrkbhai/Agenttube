---
paths:
  - app/Actions/Post/FinalizePostPublication.php
  - app/Jobs/PublishPost.php
  - app/Actions/Post/UpdatePost.php
  - 'app/Actions/Post/**'
---

# Post

## FinalizePostPublication is the only post settler
handle() takes the Post. Every path that can finish the post's publication must call it: PublishToSocialPlatform, ReconcileGoogleBusinessPost, RecoverStuckPosts, PublishPost (also for a post without a channel) and PublishPost::failed. It settles from `posts.publish_status` (published/deleted → Published, through `PublishStatus::wentOut()`; failed/rejected → Failed); a post without a channel whose publication is not finished is a no-op unless it is Publishing, which becomes Failed (with `posts.errors.choose_channel` when it still has a destination snapshot) so it does not sit non-editable forever. Do not mark the post Published / Failed by hand outside Finalize. Finalize keeps the publish time the publisher wrote (`markAsPublished()` only fills `published_at` when it is empty).

## Finalize is idempotent once the post is settled
handle() lockForUpdates the post and returns without notifying when status is already Published or Failed (Status::isSettled()). RecoverStuckPosts and ReconcileGoogleBusinessPost can both finish the post at the 24h ceiling; the second call must not send a second email. Dispatch SendNotification only after the transaction commits.

## Google Business reviews end through reconcile or the 24h ceiling
A GBP pending_review ends when ReconcileGoogleBusinessPost settles it or when RecoverStuckPosts::failExpiredReview rejects it at the 24h ceiling (prunes the JPEG, then Finalize). Disconnecting a channel deletes its posts, so no review is left without an account.

## One destination per post, stored on the post
A post has at most one destination, stored on the post itself (`posts.social_account_id`, `platform`, `content_type`, `meta`, and the publication fields). Create through CreatePosts/CreateChannelPost; never reintroduce a targets table or grouped writes. Editing uses UpdatePost and may change content type within the same account, never the social account. A legacy draft without a channel (platform null) stays editable as a draft (content, media, labels) and is turned into a channel post only through RecoverEmptyDraft; scheduling or publishing it fails with posts.errors.choose_channel.

## No per-destination validation inside a repurpose batch
ProcessRepurposeItem creates all posts of one run in a single all-or-nothing transaction (CreatePosts batch + SyncOwnedMedia). Never add per-destination/per-platform validation inside CreateChannelPost or SyncOwnedMedia: one bad destination would roll back the whole run, and repurpose items are never retried. Destination health stays a publish-time failure (AGENTS.md "Repurpose account health"); platform rules belong in the FormRequests/CreatePosts validation for user-driven flows.

## ImportExternalPosts is the only exception to Finalize
App\Actions\Post\ImportExternalPosts is the single path allowed to create Published posts (origin network) without FinalizePostPublication. Those posts were already published on the network, not by TryPost, so they are written quietly under Post::withoutEvents: no notification, webhook, PostHog event or job. Every post TryPost publishes itself still settles through Finalize.

## PostApproval is the only approval gate
Every post write that can schedule, queue or publish passes the acting user to CreatePosts / UpdatePost so App\Support\PostApproval can store Status::PendingApproval. Do not gate in controllers, API or MCP tools, and do not pass an actor from system callers (ScheduleNextOccurrence), or approved recurring series start asking again. A pending queue request is never placed in the queue; ApprovePost replays it through UpdatePost as the approver. Appending media to a post (MCP/API attach) goes through AppendPostMedia, never Post::appendMedia directly from an entry point, so an approved post edited by a requester returns to approval. Approve, reject and any UpdatePost of a pending post run under PostApproval::whilePending (lock post-approval:{id}, re-entrant).

## Defer ambiguous captionless Instagram imports
When a captionless Instagram discovery has an unresolved TryPost candidate in the same channel, compatible content type and configured publication-time window, defer importing it without claiming either ID. Do not infer identity from empty captions or timestamps. The owner accepted that a genuine native post in that window may also wait. Exact-ID matches and provider-confirmed originals keep their normal behavior (2026-10-08).

## Instagram discovery can precede publish completion
Discovery can see a live Instagram post while PublishToSocialPlatform is still Publishing or Retrying after losing media_publish's response. Defer matching discoveries without assigning their IDs during that window too; Retrying requires an Instagram container checkpoint. Keep channel, content type, caption and time-window guards. Published-only matching leaves a duplicate-import race.

## A Facebook video keeps its video id on the post
TryPost saves a Facebook video or reel under its video id; discovery reports it under its Page post id with the video id in provider_metadata.video_id (a single photo can carry photo_id the same way). ImportExternalPosts merges that discovery into the post's publication through UpsertAnalyticsPublication::mergeDiscovery(): the publication takes the Page post id, the post keeps the video id, and same-day snapshots combine through WritePublicationDailySnapshot::combine(), the same-day rule of every read (a measured value wins, a lifetime count never goes down). A Page post matched only through its video_id or photo_id is the TryPost post's own only when it was published within ImportExternalPosts::OWN_PAGE_POST_WINDOW_MINUTES (120) of the post and is the one available publication of the channel carrying that media in that window (every production match was within 227 seconds); any doubt leaves it unlinked. The merge itself is described in .ai/rules/analytics.md. Never move the post to the Page post id (reconcileRemoteId does, for TikTok's video id and the Instagram and TikTok ids claimedBySentPost resolves): repurpose recognises what TryPost published by comparing the source's video ids with posts.platform_post_id (PollRepurposeSource::idsPublishedByTryPost), so a moved post would be repurposed again.
