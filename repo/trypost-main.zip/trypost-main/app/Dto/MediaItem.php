<?php

declare(strict_types=1);

namespace App\Dto;

use App\Enums\Media\CoverSource;
use App\Enums\Media\Source;
use App\Enums\Media\Type;
use App\Enums\SocialAccount\Platform;
use App\Models\Media;

class MediaItem
{
    /**
     * @param  array<string, mixed>|null  $meta
     * @param  array<string, mixed>|null  $source_meta
     */
    public function __construct(
        public readonly string $id,
        public readonly string $path,
        public readonly string $url,
        public readonly ?string $mime_type = null,
        public readonly ?string $original_filename = null,
        public readonly ?Source $source = null,
        public readonly ?array $source_meta = null,
        public readonly ?array $meta = null,
        public readonly ?Type $type = null,
        public readonly ?int $size = null,
    ) {}

    /**
     * The item to store in `posts.media` for an asset. Carries `meta` so the
     * publish-time checks can read the measured video duration; alt text only
     * applies to images.
     */
    public static function fromMedia(Media $media, ?string $alt = null): self
    {
        $meta = $media->meta ?? [];

        if (filled($alt) && $media->isImage()) {
            $meta['alt_text'] = $alt;
        }

        return new self(
            id: $media->id,
            path: $media->path,
            url: $media->url,
            mime_type: $media->mime_type,
            original_filename: $media->original_filename,
            meta: $meta ?: null,
            type: $media->type,
            size: $media->size,
        );
    }

    /**
     * The stored `posts.media` shape — the same keys the editor keeps from a
     * MediaResource response, so every attach flow writes the same item.
     *
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'path' => $this->path,
            'url' => $this->url,
            'type' => $this->type?->value,
            'mime_type' => $this->mime_type,
            'original_filename' => $this->original_filename,
            'size' => $this->size,
            ...array_filter([
                'meta' => $this->meta,
                'source' => $this->source?->value,
                'source_meta' => $this->source_meta,
            ]),
        ];
    }

    public function isVideo(): bool
    {
        return $this->kind() === Type::Video;
    }

    public function isImage(): bool
    {
        return $this->kind() === Type::Image;
    }

    /**
     * An image that is not animated: what a video cover can be.
     */
    public function isStillImage(): bool
    {
        if (! $this->isImage()) {
            return false;
        }

        return ! Type::isGif($this->mime_type);
    }

    public function isDocument(): bool
    {
        return $this->kind() === Type::Document;
    }

    /**
     * The stored `type` wins, like `typeOf()` in ContentTypeCompatibleWithMedia
     * and `classify()` in mediaType.ts; items saved before it existed classify
     * by MIME, then by path.
     */
    private function kind(): ?Type
    {
        return $this->type ?? Type::classify($this->mime_type, $this->path);
    }

    /**
     * Stored pixel width from upload-time metadata, when known.
     */
    public function width(): ?int
    {
        $width = data_get($this->meta, 'width');

        return is_numeric($width) ? (int) $width : null;
    }

    /**
     * Stored pixel height from upload-time metadata, when known.
     */
    public function height(): ?int
    {
        $height = data_get($this->meta, 'height');

        return is_numeric($height) ? (int) $height : null;
    }

    /**
     * User-provided accessibility description for this image or video, when set.
     */
    public function altText(): ?string
    {
        $alt = data_get($this->meta, 'alt_text');

        if (! is_string($alt)) {
            return null;
        }

        $alt = trim($alt);

        return $alt === '' ? null : $alt;
    }

    /**
     * The frame, in milliseconds from the start, the user picked as this video's cover.
     */
    public function coverOffsetMs(): ?int
    {
        $offset = data_get($this->meta, 'cover_offset_ms');

        return is_numeric($offset) && $offset >= 0 ? (int) $offset : null;
    }

    /**
     * Where this video's cover comes from. A cover stored without its source
     * (sent by the API or MCP) is an uploaded image.
     */
    public function coverSource(): CoverSource
    {
        $source = CoverSource::tryFrom((string) data_get($this->meta, 'cover_source'));

        if (filled($source)) {
            return $source;
        }

        if (filled($this->cover())) {
            return CoverSource::Image;
        }

        return CoverSource::Frame;
    }

    /**
     * The image stored as this video's cover in `meta.cover`: one the user
     * uploaded, or the screenshot of the picked frame (`coverSource()` says
     * which).
     */
    public function cover(): ?self
    {
        $cover = data_get($this->meta, 'cover');

        if (! is_array($cover) || blank(data_get($cover, 'url'))) {
            return null;
        }

        return self::fromArray($cover);
    }

    /**
     * People tagged on this image, as Instagram's `user_tags` entries: a public
     * username plus x/y offsets from the top-left corner, each between 0 and 1.
     *
     * @return list<array{username: string, x: float, y: float}>
     */
    public function userTags(): array
    {
        return collect(data_get($this->meta, 'user_tags', []))
            ->filter(fn (mixed $tag): bool => is_array($tag)
                && is_string(data_get($tag, 'username'))
                && is_numeric(data_get($tag, 'x'))
                && is_numeric(data_get($tag, 'y')))
            ->map(fn (array $tag): array => [
                'username' => ltrim($tag['username'], '@'),
                'x' => min(1.0, max(0.0, (float) $tag['x'])),
                'y' => min(1.0, max(0.0, (float) $tag['y'])),
            ])
            ->values()
            ->all();
    }

    /**
     * The alt text truncated to the given platform's cap, or null when no alt
     * text is set or the platform doesn't support it. Single place that applies
     * the per-platform cap so publishers don't each repeat the truncation.
     */
    public function altTextFor(Platform $platform): ?string
    {
        $alt = $this->altText();
        $max = $platform->altTextMaxLength();

        if ($alt === null || $max === null) {
            return null;
        }

        return mb_substr($alt, 0, $max);
    }

    /**
     * The covers (`meta.cover`) of a list of stored or submitted media items.
     *
     * @param  array<int, mixed>  $items
     * @return list<array<string, mixed>>
     */
    public static function covers(array $items): array
    {
        return collect($items)
            ->map(fn (mixed $item): mixed => data_get($item, 'meta.cover'))
            ->filter(fn (mixed $cover): bool => is_array($cover))
            ->values()
            ->all();
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public static function fromArray(array $data): self
    {
        $path = data_get($data, 'path', '');
        $mimeType = data_get($data, 'mime_type') ?: Type::mimeTypeFromExtension(Type::extensionOf($path));

        $sourceValue = data_get($data, 'source');
        $source = is_string($sourceValue) ? Source::tryFrom($sourceValue) : null;

        $sourceMeta = data_get($data, 'source_meta');
        $meta = data_get($data, 'meta');
        $type = data_get($data, 'type');
        $size = data_get($data, 'size');

        return new self(
            id: (string) data_get($data, 'id', ''),
            path: $path,
            url: data_get($data, 'url', ''),
            mime_type: $mimeType,
            original_filename: data_get($data, 'original_filename'),
            source: $source,
            source_meta: is_array($sourceMeta) ? $sourceMeta : null,
            meta: is_array($meta) ? $meta : null,
            type: is_string($type) ? Type::tryFrom($type) : null,
            size: is_numeric($size) ? (int) $size : null,
        );
    }
}
