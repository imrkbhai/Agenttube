<?php

declare(strict_types=1);

namespace App\Actions\ApiKey;

use App\Enums\PostHog\ApiKeyEvent;
use App\Jobs\PostHog\CaptureAccountEvent;
use App\Models\AccessToken;
use App\Models\User;
use App\Models\Workspace;
use App\Services\PostHogService;

class CreateApiKey
{
    /**
     * @param  array{name: string, expires_at?: string|null}  $data
     * @return array{token: AccessToken, plain_token: string}
     */
    public static function execute(User $user, Workspace $workspace, array $data): array
    {
        $created = IssueApiKey::execute($user, $workspace, $data);

        rescue(function () use ($user, $workspace): void {
            CaptureAccountEvent::dispatchIf(
                PostHogService::isEnabled(),
                (string) $user->id,
                (string) $workspace->account_id,
                ApiKeyEvent::Created,
                ['workspace_id' => (string) $workspace->id],
            );
        });

        return $created;
    }
}
