<?php

declare(strict_types=1);

namespace App\Actions\Repurpose;

use App\Enums\Repurpose\PublishMode;
use App\Enums\Repurpose\SourceFormat;
use App\Enums\Repurpose\Status;
use App\Models\Repurpose;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Validation\ValidationException;

class CreateRepurpose
{
    /**
     * @param  array<string, mixed>  $data
     */
    public static function execute(Workspace $workspace, User $user, array $data): Repurpose
    {
        $sourceAccountId = data_get($data, 'source_social_account_id');
        $sourceFormat = SourceFormat::from(data_get($data, 'source_format', SourceFormat::Reel->value));

        if (self::existingFor($workspace, $sourceAccountId, $sourceFormat) !== null) {
            throw ValidationException::withMessages([
                'source_social_account_id' => __('repurposes.errors.source_already_used'),
            ]);
        }

        try {
            return Repurpose::query()->create([
                'workspace_id' => $workspace->id,
                'user_id' => $user->id,
                'source_social_account_id' => $sourceAccountId,
                'source_format' => $sourceFormat,
                'publish_mode' => PublishMode::from(data_get($data, 'publish_mode', PublishMode::Publish->value)),
                'destinations' => data_get($data, 'destinations', []),
                'status' => Status::Draft,
            ]);
        } catch (UniqueConstraintViolationException) {
            throw ValidationException::withMessages([
                'source_social_account_id' => __('repurposes.errors.source_already_used'),
            ]);
        }
    }

    public static function existingFor(Workspace $workspace, string $sourceAccountId, SourceFormat $format): ?Repurpose
    {
        return Repurpose::query()
            ->where('workspace_id', $workspace->id)
            ->where('source_social_account_id', $sourceAccountId)
            ->where('source_format', $format)
            ->first();
    }
}
