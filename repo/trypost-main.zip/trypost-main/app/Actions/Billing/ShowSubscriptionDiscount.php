<?php

declare(strict_types=1);

namespace App\Actions\Billing;

use App\Http\Resources\App\SubscriptionDiscountResource;
use App\Models\Account;
use App\Models\Subscription;
use Laravel\Cashier\Discount;

class ShowSubscriptionDiscount
{
    /**
     * The coupon on the valid subscription (`Account::validSubscription()`),
     * read from Stripe, so billing can say why the invoice is lower than the
     * plan price.
     *
     * @return array{value: string, duration: string, ends_at: string|null}|null
     */
    public static function execute(Account $account, ?Subscription $subscription): ?array
    {
        if (blank($subscription) || ! $account->hasStripeId()) {
            return null;
        }

        return transform($subscription->discount(), fn (Discount $discount): array => SubscriptionDiscountResource::make($discount)->resolve());
    }
}
